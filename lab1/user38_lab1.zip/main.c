#include <pthread.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include "lab1_IO.h"
#include "timer.h"

/* 
    Test first with command line argument(num_threads) = 1
*/

int num_threads;
pthread_t *threads;
// matrix info
int n;
int **A, **B, **C;

void* matrix_block_multi(void* rank) {
    int k = (intptr_t)rank;
    int p_sqrt = sqrt(num_threads);
    // position(index) of the block
    int x = k / p_sqrt;
    int y = k % p_sqrt;
    int b_size = n / p_sqrt;

    for (int i = b_size*x; i < b_size*(x+1); i++) {
        for (int j = b_size*y; j < b_size*(y+1); j++) {
            int sum = 0;
            for (int l = 0; l < n; l++) {
                sum += A[i][l] * B[l][j];
            }
            C[i][j] = sum;
        }
    }
    
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    // identify command line argument
    if (argc == 1) {
        num_threads = 1;
    } else if (argc == 2) {
        if (!sscanf(argv[1], "%d", &num_threads)) {
            // check if the argument is legal
            printf("Illegal Number of Threads: %s\n", argv[1]);
            exit(1);
        } else if (pow((int)sqrt(num_threads), 2) != num_threads) {
            // check if num_threads is square number
            printf("Illegal Number of Threads: %s\n", argv[1]);
            exit(1);
        }
        printf("Number of Threads: %d\t", num_threads);
    }

    // load data_input
    if (Lab1_loadinput(&A, &B, &n)) {
        printf("Fail to load data_input\n");
        exit(1);
    }
    C = malloc(n * sizeof(int**));
    for (int i = 0; i < n; i++) {
      C[i] = malloc(n * sizeof(int));
    }

    double start, end;
    GET_TIME(start);

    threads = malloc(num_threads * sizeof(pthread_t));
    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, matrix_block_multi, (void*)(intptr_t)i);
    }
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    GET_TIME(end);

    double time;
    time = end - start;
    printf("Time for threads: %f seconds\n", time);

    Lab1_saveoutput(C, &n, time);

    // free memory of matrix C
    free(C);

    exit(0);
}