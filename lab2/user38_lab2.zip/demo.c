#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include "common.h"
#include "timer.h"

char **theArray;
int n;
pthread_mutex_t *mutexes;
double *latencies;
int request_count = 0;
pthread_mutex_t request_count_mutex;

void signalHandler(int signal) {
    // Free dynamically allocated memory
    if (theArray != NULL) {
        int i;
        for (i = 0; i < n; i++) {
            free(theArray[i]);
        }
        free(theArray);
    }
    if (latencies != NULL) {
        free(latencies);
    }
    if (mutexes != NULL) {
        int i;
        for (i = 0; i < n; i++) {
            pthread_mutex_destroy(&mutexes[i]);
        }
    }
    pthread_mutex_destroy(&request_count_mutex);
    // Print a message indicating the signal received
    printf("\nDemo Program: Signal %d received. Free memory & exiting...\n", signal);
    // Exit the program
    exit(EXIT_FAILURE);
}

void initializeArray() {
    int i;
    /* Create the memory and fill in the initial values for theArray */
    theArray = (char**) malloc(n * sizeof(char*));
    for (i = 0; i < n; i ++){
        theArray[i] = (char*) malloc(COM_BUFF_SIZE * sizeof(char));
        sprintf(theArray[i], "theArray[%d]: initial value\n", i);
        // printf("%s\n\n", theArray[i]);
    }

    mutexes = malloc(n * sizeof(pthread_mutex_t));
    for (i = 0; i < n; i++) {
        pthread_mutex_init(&mutexes[i], NULL);
    }
    latencies = malloc(COM_NUM_REQUEST * sizeof(double));
    pthread_mutex_init(&request_count_mutex, NULL);
}

void *handleRequest(void *arg) {
    int client_sock = *(int *)arg;
    free(arg);

    double start, end;
    ClientRequest req;
    char buffer[COM_BUFF_SIZE];

    ssize_t bytes_read = read(client_sock, buffer, COM_BUFF_SIZE);
    if (bytes_read <= 0) {
        if (bytes_read == 0) {
            printf("Client closed the connection\n");
        } else {
            perror("read failed\n");
        }
        close(client_sock);
        return NULL;
    }

    if (bytes_read > 0) {
        buffer[bytes_read] = '\0'; // Null-terminate the string
        ParseMsg(buffer, &req);
        GET_TIME(start);
        pthread_mutex_lock(&mutexes[req.pos]); // lock the mutex
        if (req.is_read) {
            getContent(buffer, req.pos, theArray);
        } else {
            setContent(req.msg, req.pos, theArray);
            getContent(buffer, req.pos, theArray);
        }
        // printf("buffer content (%d):%s buffer length: %d\n",req.is_read,buffer,strlen(buffer));
        GET_TIME(end);
        // send the message back to the client
        write(client_sock, buffer, strlen(buffer)); 
        pthread_mutex_unlock(&mutexes[req.pos]); // unlock the mutex
        close(client_sock);
    }

    // record latency
    double operation_time = end - start;
    pthread_mutex_lock(&request_count_mutex);
    latencies[request_count++] = operation_time;
    pthread_mutex_unlock(&request_count_mutex);
    
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    // get user command
    if (argc != 4) {
        fprintf(stderr, "Usage: %s n_positions server_IP server_port\n", argv[0]);
        exit(1);
    }
    n = atoi(argv[1]);
    char *server_ip = argv[2];
    int server_port = strtol(argv[3], NULL, 10);

    // theArray initialization
    initializeArray();
    // free memory if the program is terminated manually
    signal(SIGINT, signalHandler);

    int server_fd, client_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr(server_ip);
    address.sin_port = server_port;

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) >= 0) {
        printf("socket has been created\n");
        listen(server_fd, COM_NUM_REQUEST);
        int i;
        // Allocate memory to store thread identifiers
        
        while(1) {
            pthread_t *threads = malloc(COM_NUM_REQUEST * sizeof(pthread_t));
            for (i = 0; i < COM_NUM_REQUEST; i++) {
                client_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
                
                // dynamically allocate memory for client file descriptor
                int *client_sock = malloc(sizeof(int));
                *client_sock = client_socket;

                // Create the thread and store its identifier
                pthread_create(&threads[i], NULL, handleRequest, client_sock);
            }
            // Wait for all threads to finish
            for (i = 0; i < COM_NUM_REQUEST; i++) {
                pthread_join(threads[i], NULL);
            } 

            free(threads);

            // Calculate and save the average latency
            saveTimes(latencies, COM_NUM_REQUEST);
            request_count = 0;        
        }
        close(server_fd);
    } else {
        printf("socket creation failed\n");
    }

    // Cleanup
    int i;
    for (i = 0; i < n; i++) {
        free(theArray[i]);
        pthread_mutex_destroy(&mutexes[i]);
    }
    pthread_mutex_destroy(&request_count_mutex);
    free(theArray);
    free(latencies);

    return 0;
}
