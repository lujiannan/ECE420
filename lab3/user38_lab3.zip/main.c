#include "Lab3IO.h"
#include "Lab3IO.c"
#include "timer.h"

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "omp.h"

// number of thread
int thread_count;
// problem size (shall keep the same as the matrix_size in Makefile)
int n = 100;

double** gaussian(double** A) {
   double* temp = CreateVec(n + 1);
   // threads take turns to calculate
# pragma omp parallel num_threads(thread_count)
   for (int k = 0; k < n - 1; k++) {
# pragma omp single
      {
         // int my_rank = omp_get_thread_num();
         // printf("Hello from thread %d of %d\n", my_rank, thread_count);

         // find the row with largest abs value of the first non-zero element
         int obj_row = k;
         double max_val = 0.0;
         for (int l = k; l < n; l++) {
            double val_temp = fabs(A[l][k]);
            if (val_temp > max_val){
               obj_row = l;
               max_val = val_temp;
            }
         }
         // swap it with the k's row
         if (obj_row != k) {
            temp = A[k];
            A[k] = A[obj_row];
            A[obj_row] = temp;
         }
      }
# pragma omp for
      // eliminate the following rows
      for (int i = k + 1; i < n; i++) {
         double result_temp = A[i][k] / A[k][k];
         for (int j = k; j < n + 1; j++) {
            A[i][j] -= result_temp * A[k][j];
         }
      }
   }
   DestroyVec(temp);
   return A;
}

double** jordan(double** A) {
# pragma omp parallel num_threads(thread_count)
   for (int k = n - 1; k > 0; k--) {
#pragma omp for
      for (int i = 0; i < k; i++) {
         A[i][n] = A[i][n] - A[i][k] / A[k][k] * A[k][n];
         A[i][k] = 0;
      }
   }
   return A;
}

int main(int argc, char* argv[]) {
   printf("--------------------\n");
   // identify command line argument
   if (argc != 2) {
      printf("Usage: ./main <thread_count>\n");
   } else {
      if (!sscanf(argv[1], "%d", &thread_count)) {
         // check if the argument is legal
         printf("Illegal Number of Threads: %s\n", argv[1]);
         exit(1);
      }
      printf("Number of Threads: %d\n", thread_count);
   }

   // malloc and read data
	// double** A = malloc(n*(n+1) * sizeof(double));
   double** A = CreateMat(n, n + 1);
	if (Lab3LoadInput(&A, &n) != 0) {
		// DestroyMat(A, n);
      free(A);
		return EXIT_FAILURE;
	}
   
   // timing
   double start, end;
   GET_TIME(start);

   // Run elimination
   A = gaussian(A);
   A = jordan(A);
   // PrintMat(A, n, n+1);

   GET_TIME(end);
   printf("Calculation with %d threads on the matrix takes %f seconds.\n", thread_count, (end - start));

   // save the results
   double* x = CreateVec(n);
   for (int i = 0; i < n; i++) {
      x[i] = A[i][n] / A[i][i];
   }
   Lab3SaveOutput(x, n, (end - start));

   // free memory (DestroyMat is wrong!!!)
   free(A);
   DestroyVec(x);
}